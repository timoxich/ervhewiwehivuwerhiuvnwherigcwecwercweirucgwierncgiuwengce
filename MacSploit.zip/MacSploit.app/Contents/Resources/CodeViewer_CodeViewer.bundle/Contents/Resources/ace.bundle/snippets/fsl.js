define("ace/snippets/fsl",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope=""});                (function() {
                    window.require(["ace/snippets/fsl"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            